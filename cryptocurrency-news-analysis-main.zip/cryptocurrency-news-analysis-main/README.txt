Python script that analyses news headline or body sentiment and returns the overall media sentiment of any given coin. 

It can take multiple coins and keywords as input.
You will need an account with RAPID API, and keys to the two APIs used in the script.

Please see my blog for a complete guide: https://www.cryptomaton.org/2021/04/05/how-to-analyse-daily-news-sentiment-for-cryptocurrency-with-python/
